chrome.app.runtime.onLaunched.addListener(function() {
  chrome.app.window.create('index.html', {
    'outerBounds': {
      'width': 900,
      'height': 500
    },
    'frame':'none'
  });
});

var nwcm="newwin3"
var ntcm="newtabd"

chrome.contextMenus.removeAll()
chrome.contextMenus.create({
  type:'normal',
  contexts:['all'],
  title:'New Window',
  id: nwcm
});
chrome.contextMenus.create({
  type:'normal',
  contexts:['launcher'],
  title:'New Window',
  id: "newwinlauncher"
});
chrome.contextMenus.create({
  type:'normal',
  contexts:['all'],
  title:'New Tab',
  id: ntcm
});

chrome.contextMenus.onClicked.addListener(function(info,h){
  if(!document.hasFocus()){return 0}
  var item=info.menuItemId;
  if(item=="newwinlauncher"){
  chrome.app.window.create('index.html', {
    'outerBounds': {
      'width': 900,
      'height': 500
    },
    'frame':'none'
  });
  }
})
let browser = {
  cfg: {
      tabNb: 0,
      currentTab: 0,
      tabId: [],
      version: 1.2,
      bgColor: "",
      txtColor: "",
  },
  protocols: {
      newtab: `
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <meta http-equiv="X-UA-Compatible" content="IE=edge">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>New Tab</title>
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Lexend&display=swap" rel="stylesheet">
      </head>
      <body style="width: 100vw; height: 100vh; display: flex; justify-content: flex-start; align-items: center; overflow: hidden; font-family: 'Lexend', sans-serif; margin-left: 50px; color: white; background: indigo">
                  <div id="centered" style="display: flex; flex-direction: row; justify-content: flex-start; align-items: center; flex-wrap: wrap;">
                      <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAm4SURBVHgB7d3xcds2FAbwz73+X2eCMhM0maDyBEkmqD1BkwkiT9B0gsgTJJ3A7ARxJjAzQd0JWLwSujiKJUukJHwP7/vd8excr61i4wMeQBA8QQF9Ak4XJycnC0gYP0AkMAVAQlMAJDQFQEJTACQ0BUBCUwAkNAVAQlMAJDQFQEJTACQ0BUBCUwAkNAVAQlMAJDQFQEJTACQ0BUBCUwAkNAVAQlMAJDQFQEJTACQ0BUBCUwAkNAVAQlMAJDQFQEJTACQ0BUBCUwAkNAVAQlMAJDQFQEJTACQ0BUBCUwAkNAVAQlMAJDQFQEJTACQ0BUBCUwAkNAVAQlMAJDQFQEJTACQ0BUBCUwAkNAVAQlMAJDQFQEJTACQ0BUBCUwAktB8hRfR9f5q+NOl6lq7TfP2c/3Gz5l/r8tcv9/5s193JyckNZGcKwJGkBj/D0Nh/SZd932CP0n/fvlgIunR9zt+3KRh3kLUUgAPJPfzLdP2av57i8J7l6+W9z2FBsOsvKBDfUQD2LPf0b/G1tCltGYpz+0P6fG36coUhDB2CUwD2IPf2v6frNTga/SazfNnnXqQvVykILYLSKtAE1vDTZb39bbrm4G/8q87TdZ3+DrfpOkdACsBIqcFYj++14a9q0vU+YhAUgB1ZjZ+uT+nbd/Df8Fc1CBYEBWBLudz5I317jWFSWbMGQxA+patBxRSALaRGYA3eev3XiMX+3rd5nlMlBeARuda3Xr9BXPNcFjWojAKwQS55aqz1x2gwrBi9REUUgAfket96/Wglz2OadH2oqSRSAFbkYd7q/RlknXkeHd1TAL5luzGj1/vbep1C8B7OnaCAPm9dlCrYRrszr5vsNALIVLZU6rYcUgBkH869lkMKgOzLucfVIc0BZN/epPnAOzihAMi+2WT4zMszygqAHEKXruceVoY0B5BDaOBkZUgjgBzSqzQKfAQxBUAOyUqgp8ylkEogOSTbRUu9NKoRQI7hjPXkCQXgeDoM+2asHPg3f12ynvInDJPH5VUTO4PoDIQUgP2zhr08ia2z73c9gCqfM7Q84e0F6ggE5SigAOyHNXpb7bAT1272PenLzyTbwzm/wS/KUUABmKbD0OjfHWOlIz+sM4ffINCNAgrAOF26LtMvc4ECchA8PrhDNwpoGXQ31stfYrjNv0AhNqdI19P07Z/wZZYPD6ahAGyvxdDw5yw3dtLnsHnBJXyhKt9UAm2Heotv+nHOQX7D6R6qu8MaATbrMEzcqPe326gEPyOBLfGeg4QCsN7yYe8WDuQQXMGHFyChEuhhLYadjK5OOsg30OxMowb8mvTz/YLCNAJ8z96Y4vKYj/yZL+DDKxBQAL5ljf8cjuWSzcPyKEUZpBLoK/eNfymXQvb2GvZDfZ+UHmk1Agw+1tL4TW5UHkaB4idNKwDDao+XunkXtnTLPo8p/qad6AHo4HC1Zxv578S+LFp8HhA5AMvzazrUi/qB9KTJ85ViIgfgTeWNf7ki1ILbDAVFDUCxrcwF/A1uMxQUMQA3edtAFAtwa1BQtAB0ILkDeSy5zOvA6xcUFC0Al7XX/Wv8BV5FJ8KRArAIVPevYj+puUEhUQLQwd+TU/vUgluxG2JRAhC19Plf/rsz3+xrUEiEAEQufe5jLoN+RiG1B6BD7NLnvs/g1aCQ2gPwZ+TSZ0UHXg0KqTkAHfvD7EfWgZeWQQ/gDeQ+5jmAArBnC/ZX8xRAveU73QwrMhGu9ZHIp6r9v0d+GkeRUyJqHAEWavxrdeD1FAXUFoDl4bXysOqefJuqtgBo2XMz3Q1eUVMAOvDvfRcyNQXgSr3/o4ofRcimlgB0UO8vI9QSAPX+MkoNAeig3l9GqiEArXp/GauGAGjdX0bzHgDd9a1HkXsU3gOg3n83P4GXArAj1f67Y39fwNF5DoC3l0TLZhoBdtBpv/8oDXj9gwK8BkC1/zi0JVCpN0Z6DUALGYM1AMV2qXoMgJY+R+j7vgGvDoV4DIAmv+M04KURYEt2tj/7Qa+sGvAqdmiXtwCo9x+vAa8OhXgLQAsZq+iLKB7RoRBPAdDkd5oGvDoU4ulcoLP81kPZUX4DS5EbTdtIv9ci7dB4GQE6Nf5Jir+RfYMWBXkJAPM7rjx4CV5Fj233EgCd8jwN8wS46LK2hwDcaPI7Xr4DPAMvBeARWvufZgZed6VvbHoIQAuZ4gV4/Y3C2AOgp74myOUP8wS4+DMd7AG4gkwxA7cWhbHfCNOLLiZIP+Zb8N4BtsWN5yiMeQRQ+TNBavxW+jTgVbz+N8wBUPkzze/gtgAB6hEAMkrq/c/BXf93LM91sAZA5c80b8GN5lAD1gBo789Iqfe30qcBtxYkaEcAyM7yuv8c3Kie62AMAE196NA1+I8/pFrcYAyAyp8RUu9vdX8DbnTPdTAGQEce7ijX/XPwozvRj+1OsO0OfALZWvpR/gYfr4iy3r/I2+A3YRsBKO4OepHv9np5WIjyPNcfwUXlz5Yc9fzGev8FCLGNAC3kUanx/wFfb8bUad739Q/7BNnI1vnTdd378gHEmEog1f9r9MO5PrbS8xr+XnP0BsSYAqD6/wH9sLHNwxr/Qy61p+sBDwyTFKeW9UOJ8cEaXe51S32O03S9tZ9L79ctHGC5D2C7P89AYOWztRjuTN8c+g5m//X5XXuIfQb/XDzNx1ICsW5/mOULORe2R6nDcJqZfX+X/2w38LZ6yUNu6Da62HGFdmBVk/8fNb3C1E3pwzICPGfZANcP5djYxniH9W87OUWM9/R+TL/LV3CCIQBU2x967gfJ2XUYTvHu4ATDjTC25U9txR7HRj5Xjd8wBIBt+bPI+2orcOFxyZMhAGw9rkaA3dmk1+V9nNJzALrtz3mVxsUaNglr/HM4VXoEoNv+kIfxYu+tdcZ14zelA9CCkw7lepz7xm9KB4C13ta+pM2qaPym5ByA+vFH3Q9Y64L14ZYxSo4A7KstKoO+tVznX6AiJQPAvv/fnrXVZHhgndXzGl9VWzIALYjlzW3UD3Mcib2jzd0d3m2VnAM82XYHZUnpo9ppazPEY7+bC683uLZVagS48dD4swsMm7wiaTGUPNWvhpUKgJv9Nnnot+29EeYDXbpe2cNJtZY8q0oFoIUj+VmFC9TLwm1Hl4To9YtLdfUMDqXP/czuD/R1ed8P+59CKjIJ9iw3FpsYN/CtxXBHt4XIrlIQ5r0/dsrEuz5wjy971A/HqCx6ftf9ENgIzyTLsfWcQbjth95+BllLc4A96oce9v7ZPsfqcZfHs9j2Elux0ls2t6QAHFDufe38n18xTJqfYZoOQ2O3Rv4l/1mNfYL/AAocco713F64AAAAAElFTkSuQmCC">
                      <div display: flex; justify-content: flex-start; align-items: center;>
                          <h1>Welcome to Border !</h1>
                          <p>
                              For searching just type it in the search bar and click the arrow button.
                          </p>
                      </div>
                  </div>
      </body>
      </html>
      `,
      about: `
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <meta http-equiv="X-UA-Compatible" content="IE=edge">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>New Tab</title>
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Lexend&display=swap" rel="stylesheet">
      </head>
      <body style="width: 100vw; height: 100vh; overflow: hidden; font-family: 'Lexend', sans-serif; margin-left: 50px; color: white; background: indigo">
                  
                  <h1>About Border.</h1>
                  <p>
                  Border is an iframe Web browser developped by <a style="color: white;" href="github.com/Onofficiel">Onofficiel</a><br> accessible on all platforms.<br>Because of the iframe system some website won't work in this browser (like Google.com),<br>but you can always use bing.
                  <br><br>Thanks to <a style="color: white;" href="https://billygoat891.tk">billygoat891</a> for hosting the project on windows96.
                  </p>

                  <p style="position: absolute; bottom: 0; left: 50%; transform: translateX(-50%)">Border v1.2 | © Onofficiel - 2021 - All rights reserved</p>
      </body>
      </html>
      `,
      404: `
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <meta http-equiv="X-UA-Compatible" content="IE=edge">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>404</title>
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Lexend&display=swap" rel="stylesheet">
      </head>
      <body style="width: 100vw; height: 100vh; display: flex; justify-content: flex-start; align-items: center; overflow: hidden; font-family: 'Lexend', sans-serif; margin-left: 50px; color: white; background: rgb(247, 37, 58)">
                  <div id="centered">
                      <h1>404</h1>
                      <p>
                          Not found.
                      </p>
                  </div>
      </body>
      </html>
      `,
      woozy: `
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <meta http-equiv="X-UA-Compatible" content="IE=edge">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Wooooooooooooooooooooooooozy</title>
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Lexend&display=swap" rel="stylesheet">
      </head>
      <body style="width: 100vw; height: 100vh; display: flex; justify-content: flex-start; align-items: center; overflow: hidden; font-family: 'Lexend', sans-serif; margin-left: 50px; color: white; background: rgb(255, 204, 77)">
                  <div id="centered">
                      <img src="https://hotemoji.com/images/dl/t/woozy-face-emoji-by-twitter.png">
                  </div>
      </body>
      </html>
      `,
      plugins: `<!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <title>Border Plugins</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Lexend&display=swap" rel="stylesheet">
        <style>
        html,body{
        margin:0 !important;
        padding:none !important;
        font-family: Lexend,sans;
        }
        .border-plugins-header{
        color:white;
        background-color:indigo;
        width:100%;
        font-size: 16px;
        position:sticky;
        }
        </style>
      </head>
      <body>
        <div class="border-plugins-header">
        Border Plugins
        </div>
        <div class="border-plugin-list">
        You don't have any plugins
        </div>
      </body>
      </html>`,
      get bookmarks(){
        return`<!DOCTYPE html>
      <html>
      <head>
      <title>Bookmarks</title>
      </head>
      <body>
      <div class="bookmarklist">
      </div>
      <script>
      onmessage=console.log
      function lbm(list){
      for(var i=0;i<list.length;i++){
      var el=document.createElement("div");
      el.innerText=list[i].name+"("+(list[i].type=='folder'?"borbm:fold":list[i].path)+")";
      document.querySelector('.bookmarklist').appendChild(el);
    }
      }
      window.addEventListener('message',function(G){
      //console.log(G)
      //lbm(JSON.parse(G.data).list)
      })
      lbm(${JSON.stringify(window.Bookmarks)})
      </script>`
    },
      get flags(){
        return `Border Scripting <button onclick="win.postMessage(JSON.stringify({flag:'enable',fn:this.dataset.flag}),'*')" data-flag="scripting">Enable</button><button onclick="win.postMessage(JSON.stringify({flag:'off',fn:this.dataset.flag}),'*')" data-flag="scripting">Disable</button>
        <script>window.onmessage=function(e){window.win=e.source}</script>`
      }
  },
  verifyProtocol: (url) => {

      if (/^\S*:/i.test(url)) {

          for (let i = 0; i < Object.keys(browser.protocols).length; i++) {
              const protocol = Object.keys(browser.protocols)[i];

              if (RegExp("^border:\/*" + protocol).test(url)) {
                  return encodeURI("data:text/html," + browser.protocols[protocol]);
              }
          }
          return url;
      } else {
          return "https://" + url;
      }

  },
  addTab: (tab) => {

      if (!tab)
          throw new Error("You have to add an object for creating a tab.");
      if (!tab.url)
          tab.url = "border://newtab";



      // Create an html tab div
      let tabElement = document.createElement("div");
      tabElement.classList.add("tab");
      tabElement.dataset.id = browser.generateId();
      tabElement.dataset.url = tab.url;
      tabElement.dataset.console=JSON.stringify([])
      tabElement.innerHTML = "<div class='title'>Name Undefined</div><div class='close-btn'>×</div>";

      tabElement.addEventListener("click", () => {
          browser.setCurrent(tabElement.dataset.id);
      });

      tabElement.querySelector(".close-btn").addEventListener("click", () => {
          browser.removeTab(tabElement.dataset.id);
      });

      document.querySelector("#tab-container").appendChild(tabElement);
      // <

      // Create an html view tab
      let viewElement = document.createElement("webview");
      viewElement.addEventListener('permissionrequest',function(E){
        E.preventDefault
        handlePermission(E,viewElement)
        //E.request.allow()
      })
      viewElement.classList.add("view");
      viewElement.dataset.id = tabElement.dataset.id;
      if(tab.win){
        tab.win.attach(viewElement);
        tabElement.dataset.url=viewElement.src;
      }

      document.querySelector("#view-container").appendChild(viewElement);
      // <

      // After Ctreated Action
      if (tab.current){
          browser.setCurrent(tabElement.dataset.id);}
          if(!tab.win){
      browser.reloadTab();
          }
      // <
      var olu=viewElement.src;
      setInterval(function(){
        if(olu!=viewElement.src){
          olu=viewElement.src;
          tabElement.querySelector('.title').innerText=browser.correct3(olu);
          tabElement.dataset.url=browser.correct(olu)
          if(tabElement.classList.contains('current')){
            document.querySelector('#searchbar').value=tabElement.dataset.url
          }
        }
      })
      viewElement.addEventListener('close',function(){
        browser.removeTab(tabElement.dataset.id);
      });
      viewElement.addEventListener('newwindow', function(e) {
        var as=e.windowOpenDisposition;
        var w=e.initialWidth;var h=e.initialHeight;
        if(as=="new_window"||as=="new_popup"){
          e.preventDefault();
          attachBra(e,w,h);
          return
        }
        browser.addTab({
          win:e.window,
          current:true
        })
      });
      viewElement.contextMenus.create({
        contexts: ['all'],
        type:'separator'
      });
      viewElement.contextMenus.create({
        contexts: ['all'],
        type:'normal',
        title:'Console',
        onclick:function(){
          toggleConsole()
        }
      });
      viewElement.addEventListener('contentload',function(){
        if(tabElement.dataset.url=="border://bookmarks"){
          setTimeout(function(){
            viewElement.contentWindow.postMessage(JSON.stringify({BORDERINTERNALURL:"/bookmarks"}),'*');
          },1000)
        }
        if(tabElement.dataset.url=="border://flags"){
          setTimeout(function(){
            viewElement.contentWindow.postMessage(JSON.stringify({BORDERINTERNALURL:"/flags"}),'*');
          },1000)
        }
        viewElement.executeScript({
          code: `var id="BORDER-INTERNAL-SCRIPT-"+(Math.random()*10);var src=\`(function(){
          var ml=function o(e){
          if(e.origin.indexOf('chrome-extension://')==0){
          window.removeEventListener('message',ml);
          window.moveTo=function(x,y){
          e.source.postMessage("moveto:"+x+":"+y,e.origin)
        }
        }
      }
        document.body.removeChild(document.getElementById(\${JSON.stringify(id)}))

        window.addEventListener('message',ml);
          })()
          \`;
          var scr=document.createElement('script');
          scr.id=id;
          scr.innerHTML=src;document.body.appendChild(scr);`
        },function(){
          setTimeout(function(){
          viewElement.contentWindow.postMessage("BorderDesktop!!THERE:q?",'*')},1000);
          if(Flags.loaded.indexOf('scripting')>-1){
            viewElement.contentWindow.postMessage("__FromBorder__",'*')
          }
        })
      });
      viewElement.addContentScripts([
        {
          name: "borderservices",
          matches:['<all_urls>'],
          js:{code:BorderRuntimeBroker()},
          match_about_blank:true,
          all_frames:true
        }
      ]);
      viewElement.addEventListener('consolemessage',function(e) {
        console.log(e)
        if(e.level==1){
          browser.addToConsole(tabElement.dataset.id,{
            type:'console-warn',
            text:e.message
          });
        } else if(e.level==2){
          browser.addToConsole(tabElement.dataset.id,{
            type:'console-error',
            text:e.message
          });
        } else if(e.level==-1){
          browser.addToConsole(tabElement.dataset.id,{
            type:'console-debug',
            text:e.message
          });
        } else {
          browser.addToConsole(tabElement.dataset.id,{
            type:'console-info',
            text:e.message
          });
        }
      })
      browser.cfg.tabNb++;
      browser.cfg.tabId.push(tabElement.dataset.id);
  },
  getConsoleHTML:function(con){
    var d=document.createElement('xoxo');
    var y;
    for(var i=0;i<con.length;i++){
      y=document.createElement('div');
      y.className=con[i].type;
      y.innerText=con[i].text;
      d.appendChild(y);
    }
    return d.innerHTML
  },
  correct: function(url){
    if(url==browser.verifyProtocol('border://newtab')){
      return 'border://newtab'
    }
    if(url==browser.verifyProtocol("border://flags")){
      return 'border://flags'
    }
    if(url==browser.verifyProtocol('border://bookmarks')){
      return 'border://bookmarks'
    }
    if(url==browser.verifyProtocol('border://woozy')){
      return 'border://woozy'
    }
    if(url==browser.verifyProtocol('border://about')){
      return 'border://about'
    }
    if(url==browser.verifyProtocol('border://404')){
      return 'border://404'
    }
    if(url==browser.verifyProtocol('border://plugins')){
      return 'border://plugins'
    }
    return url
  },
  correct3:function(url){
    var xyz=browser.correct(url);
    try {
      return (new URL(xyz)).hostname || xyz
    } catch (e){
      return xyz
    }
  },
  removeTab: (id) => {

      if (id !== undefined) {
          document.querySelector("#tab-container").removeChild(document.querySelector('.tab[data-id~="' + id + '"]'));
          document.querySelector("#view-container").removeChild(document.querySelector('.view[data-id~="' + id + '"]'));
      }

      browser.cfg.tabNb--;
      browser.cfg.tabId.splice(browser.cfg.tabId.indexOf(id), 1);

  },
  setCurrent: (id) => {

      try {
          for (let i = 0; i < document.querySelector("#tab-container").querySelectorAll(".tab").length; i++) {
              document.querySelector("#tab-container").querySelectorAll(".tab")[i].classList.remove("current");
          }
          document.querySelector('.tab[data-id~="' + id + '"]').classList.add("current");

          for (let i = 0; i < document.querySelector("#view-container").querySelectorAll(".view").length; i++) {
              document.querySelector("#view-container").querySelectorAll(".view")[i].classList.remove("current");
          }
          document.querySelector('.view[data-id~="' + id + '"]').classList.add("current");

          document.querySelector("#searchbar").value = document.querySelector(".tab.current").dataset.url;
      } catch { }

  },
  reloadTab: () => {

      document.querySelector("#searchbar").value = browser.correct(document.querySelector(".tab.current").dataset.url);
      document.querySelector("#view-container").querySelector(".view.current").src = browser.verifyProtocol(document.querySelector("#tab-container").querySelector(".tab.current").dataset.url);
      document.querySelector(".tab.current").querySelector(".title").innerText = browser.correct3(document.querySelector('.tab.current').dataset.url)
  
  },
  generateId: () => {

      let id = "";
      for (let i = 0; i < 4; i++) {
          id += Math.floor(Math.random() * 10);
      }

      if (browser.cfg.tabId.length >= 9999)
          throw new Error("Cannot generate ID");
      for (const tabId in browser.cfg.tabId) {
          if (tabId === id)
              return browser.generateId();
      }
      return parseInt(id);

  },
  boot: () => {
      document.querySelector(":root").style.setProperty('--bg', browser.cfg.bgColor);
      document.querySelector(":root").style.setProperty('--txt', browser.cfg.txtColor);

      if (window.location.hash&&location.hash!="#moveto")
          browser.addTab({ url: browser.verifyProtocol(decodeURI(window.location.hash.substring(1))), current: true });
      else
          browser.addTab({ current: true });

      searchbar.addEventListener("keyup", (event) => {
          if (event.key === "Enter") {
            try{
              var uu=new URL(searchbar.value);if(uu.protocol=="javascript:"){document.querySelector('.view.current').executeScript({code:searchbar.value.slice(11)});return}
            }catch(e){null}
              document.querySelector('.tab.current').dataset.url = searchbar.value;
              browser.reloadTab();
              searchbar.blur();
          }
      });
      
      document.querySelector("#tab-container").onwheel=function(wheel){
        document.querySelector("#tab-container").scrollLeft+=wheel.deltaY
      }

      setInterval(() => {
        if (document.querySelector("#tab-container").querySelectorAll(".tab").length <= 0)
            window.close()
    }, 10);
    setInterval(() => {
      if (document.querySelector("#tab-container").querySelectorAll(".tab.current").length <= 0)
          browser.setCurrent(document.querySelector('.tab').dataset.id)
    }, 10);
    setInterval(function () {
      var activetab=document.querySelector('.tab.current');
      if(activetab){
        document.querySelector('.console-messages').innerHTML=browser.getConsoleHTML(
        browser.getConsole(activetab.dataset.id)
        );
      }
    },10)

  },
  clearConsole:function(id){
    var tab=document.querySelector('.tab[data-id~="'+id+'"]');
    if(tab){
      tab.dataset.console=JSON.stringify([])
    }
  },
  getConsole:function(id){
    var tab=document.querySelector('.tab[data-id~="'+id+'"]');
    if(tab){
      try {
      return JSON.parse(tab.dataset.console)||[]
    }catch(e){return []}
    }else   {
      return []
    }
  },
  addToConsole:function(id,vab){
    var tab=document.querySelector('.tab[data-id~="'+id+'"]');
    if(tab){
      var tc=browser.getConsole(id);
      tc.push(vab);
      tab.dataset.console=JSON.stringify(tc);
    }
  }
}


document.querySelector('#search-button').onclick=function(){
  try{
    var uu=new URL(searchbar.value);if(uu.protocol=="javascript:"){document.querySelector('.view.current').executeScript({code:searchbar.value.slice(11)});return}
  }catch(e){null}
  console.log(searchbar.value)
  document.querySelector('.tab.current').dataset.url = searchbar.value;
  browser.reloadTab()
  searchbar.blur()
}

document.querySelector('#add-button').onclick=function(){
  browser.addTab({current:true});
}

document.querySelector('.back').onclick=function(){
  var curf=document.querySelector('webview.current');
  if(curf){
    curf.back()
  }
}

document.querySelector('.forward').onclick=function(){
  var curf=document.querySelector('webview.current');
  if(curf){
    curf.forward()
  }
}

document.querySelector('.refresh').onclick=function(){
  var curf=document.querySelector('webview.current');
  if(curf){
    curf.reload()
  }
}


var PluginAPI={
  activeTab:{
    close:function(){
      if(document.querySelector('.tab.current')) browser.removeTab(document.querySelector('.tab.current').dataset.id)
    }
  }
}


window.addEventListener('keydown',function(e){
  if(e.keyCode==87&&e.ctrlKey){
    e.preventDefault();
    if(!e.altKey&&!e.metaKey){
      if(e.shiftKey){
        window.close()
      } else {
        PluginAPI.activeTab.close()
      }
    }
  } else if(e.keyCode==84&&e.ctrlKey){
    browser.addTab({current:true})
  } else if(e.keyCode==73&&e.shiftKey&&e.ctrlKey){
    toggleConsole()
  }
})


var SitePerms={}

function getMediaPermission(d,perm){
  var sitehref=new URL(d).origin;
  var sitedata=SitePerms[sitehref]||{}
  if(!SitePerms[sitehref]){
    SitePerms[sitehref]=PermDefault(perm,sitehref);
    chrome.storage.sync.set({'permissions':JSON.stringify(SitePerms)})
  }
  return sitedata[perm]||PermDefault(perm,sitehref)||"allow"
}

function PermDefault(perm,sh){
  var u=new URL(sh);
  var prot={
    'https:':{
      camera:"ask",
      midi:"ask",
      usb:"ask",
      location:"ask",
      fs:"ask",
      plugin:"allow",
      script:"ask"
    },
    'http:':{
      camera:"pribk",
      midi:"pribk",
      usb:"pribk",
      location:"pribk",
      fs:"ask",
      plugin:"allow",
      script:"ask"
    },
    'border:':{
      camera:"allow",
      midi:"allow",
      usb:"allow",
      location:"allow",
      fs:"allow",
      plugin:"allow",
      script:"allow"
    },
    'about:':{
      camera:"ask",
      midi:"ask",
      usb:"ask",
      location:"ask",
      fs:"ask",
      plugin:"allow",
      script:"ask"
    },
    'data:':{
      camera:"ask",
      midi:"ask",
      usb:"ask",
      location:"ask",
      fs:"ask",
      plugin:"allow",
      script:"ask"
    },
    'plugin:':{
      camera:"allow",
      midi:"allow",
      usb:"allow",
      location:"allow",
      fs:"allow",
      plugin:"allow",
      script:"allow"
    },
  }
  return (prot[u.protocol]||prot['https'])[perm]
}

function prType(E){
  var def={'filesystem':'fs',geolocation:'location',media:'camera','loadplugin':'plugin'}
  return def[E]
}

function handlePermission(e,w){
  if(e.permission=="fullscreen"||e.permission=="pointerLock"||e.permission=="download"){
    e.request.allow();return 0
  }
  e.preventDefault()
  try{
    var xyz=getMediaPermission(w.src,prType(e.permission));
    console.log(xyz)
    if(xyz=='allow'||xyz=='ask'){
      e.request.allow()
    } else {
      e.request.deny()
    }
  }catch(r){
    console.error(r)
    e.request.deny()
  }
}

var Bookmarks=[
  {
    type:'mark',
    path:'border://woozy',
    name:'WOOZY'
  }
]



function setpermission(origin,perm,val){
  if(!SitePerms[origin]){SitePerms[origin]={}}
  SitePerms[origin][perm]=val;
  chrome.storage.sync.set({"permissions":JSON.stringify(SitePerms)});
}

chrome.storage.sync.get(['permissions'],function(key){
  try{
    SitePerms=JSON.parse(key.permissions);
    chrome.storage.sync.set({"permissions":JSON.stringify(SitePerms)})
  }catch(err){null}
})

chrome.storage.sync.get(['bkm'],function(key){
  try{
    Bookmarks=JSON.parse(key.bkm||JSON.Bookmarks());
    chrome.storage.sync.set({"bkm":JSON.stringify(Bookmarks)})
  }catch(err){null}
})

var ConsoleShowing=false;
function toggleConsole(){
  ConsoleShowing=!ConsoleShowing;
  if(ConsoleShowing){
    document.querySelector('.webconsole').style.display='flex';
  } else {
    document.querySelector('.webconsole').style.display='none';
  }
}

var nwcm="newwin3"
var ntcm="newtabd"
chrome.contextMenus.removeAll()
chrome.contextMenus.create({
  type:'normal',
  contexts:['all'],
  title:'New Window',
  id: nwcm
});
chrome.contextMenus.create({
  type:'normal',
  contexts:['all'],
  title:'New Tab',
  id: ntcm
});
chrome.contextMenus.onClicked.addListener(function(info,h){
  if(!document.hasFocus()){return 0}
  var item=info.menuItemId;
  if(item==nwcm){
  chrome.app.window.create('index.html', {
    'outerBounds': {
      'width': 900,
      'height': 500
    }
  });
  }else if(item==ntcm){
    browser.addTab({current:true})
  }
})


function attachBra(e,w,h){
  e.preventDefault()
  chrome.app.window.create('index.html#moveto', {
    'outerBounds': {
      'width': w||900,
      'height': h||500
    }
  },function(G){
    var zyxe=setInterval(function(){if(G.contentWindow.document.querySelector('webview')){
      clearInterval(zyxe);
      e.window.attach(G.contentWindow.document.querySelector('webview'));}},400);
    });
}

window.onmessage=function(e){
  try{
    if(e.data.indexOf("moveto:")==0){
      if(location.hash!="#moveto"){return 0}
      var x=e.data.split(":");
      chrome.app.window.current().moveTo(x[1],x[2]);
    } else {
      var xob=JSON.parse(e.data);
      if(xob.flag=='enable'){
        addFlag(xob.fn)
      } else if(xob.flag=='off'){
        rmFlag(xob.fn)
      }
    }
  }catch(r){null}
}

var Flags={
  applied: [],
  loaded:[]
}

function rmFlag(i){
  var a=[];
  for(var x=0;x<Flags.applied.length;x++){
    if(Flags.applied[x]!=i){
      a.push(Flags.applied[x])
    }
  }
  Flags.applied=a;
  chrome.storage.sync.set({flags:JSON.stringify(Flags.applied)});
}

function addFlag(i){
  Flags.applied.push(i);
  chrome.storage.sync.set({flags:JSON.stringify(Flags.applied)});
}

chrome.storage.sync.get("flags",function(key){
  try{
    Flags.applied=JSON.parse(key.flags);
    Flags.loaded=JSON.parse(key.flags);
  }catch(e){null}
  browser.boot()
})


var BorderRuntimeBroker=function(){
return `/*
Welcome to the Border Runtime Broker (BRB).
*/
var port=chrome.runtime.connect();
window.addEventListener('message',function(e){
if(e.source!=window){return}
if(e.data.type&&e.data.type=="_BORDER_EXEC_"){
port.postMessage({borderScriptingService:e.data.exec,type:'BorderScripting.Execute'})
}
})
${(function(){
if(Flags.loaded.indexOf('scripting')>-1){
return `
var script=document.createElement('script');
var id=script.id="BORDERSCRIPTINGSCRIPT-"+Math.floor(Math.random()*100000);
script.innerText=\`
(function(){
navigator.BorderScripting={
execute:function(code){window.postMessage({
type:"_BORDER_EXEC_",
exec:code
},"*")}
}
})()
\`;
document.documentElement.appendChild(script);
`;
}
return "navigator.BorderScripting={execute:function(){}}";
})()
}
`};


chrome.runtime.onConnect.addListener(function(port){
  port.onMessage.addListener(function (data){
    if(data.borderScriptingService/*&&data.type&&data.type=="BorderScripting.Execute"*/){
      console.log("Border says "+data.borderScriptingService);
    }
  });
})
